function validateForm(){
    document.getElementById("fname_box").innerHTML="";
    document.getElementById("lname_box").innerHTML="";
    document.getElementById("address_box").innerHTML="";
    document.getElementById("city_box").innerHTML="";
    document.getElementById("postal_code_box").innerHTML="";
    document.getElementById("province_box").innerHTML="";
    document.getElementById("age_box").innerHTML="";
    document.getElementById("password_box").innerHTML="";
    document.getElementById("confirm_box").innerHTML="";
    document.getElementById("email_box").innerHTML="";
    
    
    var index;
    var province_lists = ["NF", "NS", "PE","NB", "QC", "ON","MN", "SK", "AB","BC"];
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var address = document.getElementById("address").value;
    var city = document.getElementById("city").value;
    var postal_code = document.getElementById("postal_code").value;
    var province = document.getElementById("province").value;
    var age = document.getElementById("age").value;
    var password = document.getElementById("password").value;
    var confirm = document.getElementById("confirm").value;
    var email = document.getElementById("email").value;

    if (fname == "") {
        document.getElementById("fname_box").innerHTML = "first name rquired";
        }
        if (lname == "") {
        document.getElementById("lname_box").innerHTML = "last name required";
        }
        if (address == "") {
        document.getElementById("address_box").innerHTML = "address required";
        }
        if (city == "") {
        document.getElementById("city_box").innerHTML = "city required";
        }
        if (postal_code == "") {
        document.getElementById("postal_code_box").innerHTML = "postal_code required";
        }
        if (province == "") {
        document.getElementById("province_box").innerHTML = "province required";

    var condition = 0;
    
    for (index = 0; index < province_lists.length; index++) {
    if(province_lists[index] == province) {
    
    condition = 1;
    break;
    } else {
    
    condition = 0;
    
    }
    }
    if (condition == 1) {
    
    }else{
    document.getElementById("province_box").innerHTML = "Province must be one of NF, NS, PE,NB, QC, ON,MN, SK, AB,BC";
    }
    
    }
    if (age == "") {
    document.getElementById("age_box").innerHTML = "age required";
    }else{
    if (age<18) {
    document.getElementById("age_box").innerHTML = "you`re must be older than 18";
    }
    }
    if (password == "") {
    document.getElementById("password_box").innerHTML = "password required to fill";
    }else{
    if (/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/.test(password))
    {
    }else{
    document.getElementById("password_box").innerHTML = "Password should contain 6 characters,one uppercase and one lowercase and on digit";
    }
    }
    if (confirm == "") {
    document.getElementById("confirm_box").innerHTML = "cannot be empty";
    }else{
    if(confirm.localeCompare(password) == 0) {
    
    } else {
    document.getElementById("confirm_box").innerHTML = "password and confirm password does not match";
    }
    }
    if (email == "") {
    document.getElementById("email_box").innerHTML = "email cannt be blank";
    }else{
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
    {
    }else{
    document.getElementById("email_box").innerHTML = "Email address does not in vaild form";
    }
    
    }
    
}
    
    
    function clearForm() {
    document.getElementById("fname").value = "";
    document.getElementById("lname").value = "";
    document.getElementById("address").value = "";
    document.getElementById("city").value = "";
    document.getElementById("postal_code").value = "";
    document.getElementById("province").value = "";
    document.getElementById("age").value = "";
    document.getElementById("password").value = "";
    document.getElementById("confirm").value = "";
    document.getElementById("email").value = "";
    }